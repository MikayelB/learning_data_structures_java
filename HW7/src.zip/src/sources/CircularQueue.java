package sources;

public interface CircularQueue<E> extends Queue<E> {

  void rotate();
}
